package dv5a.zipstream;

import java.io.IOException;

public class ZipStreamException extends IOException {
    ZipStreamException(String message) {
        super(message);
    }
}
